public class Person
{
   public Date getDate()
   {
      Date pong = this.getDate();
      return pong;
   }
   public String getName()
   {  
      String pong = this.getName();
      return pong;
   }
   public String getAddress()
   {
      String pong = this.getAddress();
      return pong;
   }
   public float getSalary()
   {
      float pong = this.getSalary();
      return pong;
   }
}
/*
Data Table for getDate() - in Person Class 		
Variable	Type	Use
__________________________________________		
pong	   Date	Hold the return value
		
Data Table for getAddress() - in Person Class 		
Variable	Type	Use
__________________________________________		
pong	   int	Hold the return value
		
Data Table for getName() - in Person Class 		
Variable	Type	Use
__________________________________________		
pong	   String	Hold the return value
		
Data Table for getSalary() - in Person Class		
Variable	Type	Use
__________________________________________		
pong	   float	Hold the return value
*/