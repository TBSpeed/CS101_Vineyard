public class Student extends Person
{

}